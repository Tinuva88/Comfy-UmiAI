
import re

text = "$color1={__colors__}; $color2={__colors__}; $color3={__colors__};"
# Note: user output shows $color1=Light Brown, which means __colors__ was resolved. 
# This confirms store_variables missed it, and subsequent tag_replacer resolved it in the main text.

# The regex we implemented
assign_regex = re.compile(r'\$([a-zA-Z0-9_]+)\s*=\s*(.*?)(?:;|(?=\n)|$)', re.MULTILINE)

print(f"Testing text: '{text}'")

matches = list(assign_regex.finditer(text))
print(f"Found {len(matches)} matches")

for i, m in enumerate(matches):
    print(f"Match {i}: Var='{m.group(1)}', Val='{m.group(2)}'")

# Test with resolved content as seen in output
text_resolved = "$color1=Light Brown; $color2=Light Brown;"
print(f"\nTesting resolved text: '{text_resolved}'")
matches_res = list(assign_regex.finditer(text_resolved))
for i, m in enumerate(matches_res):
    print(f"Match {i}: Var='{m.group(1)}', Val='{m.group(2)}'")

# Test replacement
def replace_func(m):
    return ""

cleaned = assign_regex.sub(replace_func, text)
print(f"\nCleaned text (original): '{cleaned}'")
