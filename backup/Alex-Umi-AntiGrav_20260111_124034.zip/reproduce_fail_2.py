
import re

class MockVariableReplacer:
    def __init__(self):
        # Current regex in shared_utils
        self.assign_regex = re.compile(r'\$([a-zA-Z0-9_]+)\s*=\s*([^;]+?)(?:\s*;|(?=\n)|$)', re.MULTILINE)
        self.variables = {}

    def store_variables(self, text):
        # We simulate the masking logic here too, just in case
        masked_text = text
        # (Masking logic skipped for this test as the input doesn't have [if])
        
        def _replace_assign(match):
            var_name = match.group(1)
            raw_value = match.group(2).strip()
            self.variables[var_name] = raw_value
            print(f"[MATCH] Var: {var_name}, Val: '{raw_value}'")
            return ""  # Remove
        
        print(f"DEBUG: Testing on string lengths: {len(masked_text)}")
        processed_text = self.assign_regex.sub(_replace_assign, masked_text)
        return processed_text

# The text that persists in the output
failure_text = "random,$color1=Red; $color2=Red; $color3=Red; $color1, $color2, $color3"

print(f"--- Testing Failure Text ---\n'{failure_text}'")

replacer = MockVariableReplacer()
result = replacer.store_variables(failure_text)

print(f"\n--- Result ---\n'{result}'")
print(f"Variables: {replacer.variables}")

if "$color1=Red" not in result:
    print("SUCCESS: Assignment removed.")
else:
    print("FAILURE: Assignment persists.")
