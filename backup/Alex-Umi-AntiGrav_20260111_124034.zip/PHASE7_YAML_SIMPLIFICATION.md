# Phase 7: YAML Simplification

## Overview
Phase 7 removes the confusing distinction between "Umi YAML" and "Alternative YAML" formats, consolidating to a single unified tag-based YAML system. This makes the codebase simpler and the user experience more consistent.

---

## Fix 21: Unified YAML Format

### Problem
The system previously supported two different YAML formats:
1. **Umi Format**: Entries with `Prompts`, `Tags`, `Prefix`, `Suffix` keys
2. **Alternative Format**: Simple hierarchical key-value pairs

This dual-format support added complexity with:
- `is_umi_format()` method to detect format type
- `flatten_hierarchical_yaml()` to process alternative format
- Separate code paths in `load_tags()` method
- User confusion about which format to use

### Solution
**Consolidated to single unified YAML format** with tag-based selection:

#### YAML Structure
```yaml
EntryName:
  Prompts: ["prompt text here"]
  Tags: [Tag1, Tag2, Tag3]
  Prefix: ["prefix text"]
  Suffix: ["suffix text"]
```

All keys are optional except the entry name. If an entry has `Tags`, it can be selected using tag-based logic.

#### Tag-Based Selection Syntax

| Syntax | Description | Example |
|--------|-------------|---------|
| `<[tag]>` | Select any entry with this tag | `<[Fire]>` |
| `<[tag1][tag2]>` | AND logic (both tags required) | `<[Fire][Warrior]>` |
| `<[tag1\|tag2]>` | OR logic (either tag) | `<[Fire\|Ice]>` |
| `<[--tag]>` | NOT logic (exclude tag) | `<[--Heavy]>` |
| `<file:[tag]>` | Specific file with tag | `<characters:[Elf]>` |

#### Boolean Logic Operators

Full logic expressions are supported:
- **AND**: `&&` or `AND`
- **OR**: `||` or `OR`
- **XOR**: `^` or `XOR`
- **NOT**: `!` or `NOT`
- **NAND**: `NAND`
- **NOR**: `NOR`
- **Grouping**: `( )`

Examples:
```
<[Fire AND Warrior]>           → Entries with both tags
<[Ice OR Fire]>                → Entries with either tag
<[(Fire OR Ice) AND Mage]>     → Ice/Fire mages only
<[NOT Heavy]>                  → Exclude heavy armor entries
<[Fire NAND Mage]>             → NOT(Fire AND Mage)
```

---

## Code Changes

### File: `nodes.py`

#### Removed Methods (lines 472-473)
**Deleted:**
```python
def is_umi_format(self, data):
    if not isinstance(data, dict):
        return False
    for key, value in data.items():
        if isinstance(value, dict):
            keys_lower = {k.lower() for k in value.keys()}
            if 'prompts' in keys_lower:
                return True
    return False

def flatten_hierarchical_yaml(self, data, prefix=""):
    results = {}
    if isinstance(data, dict):
        for k, v in data.items():
            clean_key = str(k).strip()
            new_prefix = f"{prefix}/{clean_key}" if prefix else clean_key
            results.update(self.flatten_hierarchical_yaml(v, new_prefix))
    elif isinstance(data, list):
        clean_list = [str(x) for x in data if x is not None]
        results[prefix] = clean_list
    elif data is not None:
        results[prefix] = [str(data)]
    return results
```

**Replaced with:**
```python
# Phase 7: Removed is_umi_format() and flatten_hierarchical_yaml()
# Now using unified YAML format with tag-based selection
```

#### Simplified `load_tags()` Method (lines 559-587)

**Before** (dual-path logic):
```python
if self.is_umi_format(data):
    # Process Umi format
    for title, entry in data.items():
        if isinstance(entry, dict):
            processed = self.process_yaml_entry(title, entry)
            if processed['tags']:
                self.yaml_entries[title.lower()] = processed
    # ... return prompts
else:
    # Process alternative format
    flat_data = self.flatten_hierarchical_yaml(data)
    # ... return flattened values
```

**After** (unified path):
```python
# Phase 7: Unified YAML format - always process entries with tags
if isinstance(data, dict):
    for title, entry in data.items():
        if isinstance(entry, dict):
            processed = self.process_yaml_entry(title, entry)
            # Store in yaml_entries index if it has tags
            if processed['tags']:
                self.yaml_entries[title.lower()] = processed

    # If a specific key was requested (key_suffix), return its prompts
    if key_suffix:
        for k, v in data.items():
            if k.lower() == key_suffix:
                processed = self.process_yaml_entry(k, v)
                GLOBAL_CACHE[requested_tag] = processed['prompts']
                FILE_MTIME_CACHE[requested_tag] = {
                    'path': found_file,
                    'mtime': os.path.getmtime(found_file)
                }
                return processed['prompts']
        return []

    # No specific key - return all prompts from all entries
    all_prompts = []
    for entry in data.values():
        if isinstance(entry, dict):
            processed = self.process_yaml_entry('', entry)
            all_prompts.extend(processed['prompts'])
    return all_prompts
```

**Key Improvements:**
- Single code path for all YAML files
- Cleaner logic flow
- Consistent behavior
- Maintains backward compatibility with existing YAML files

### File: `js/umi_wildcards.js`

#### Updated Documentation (lines 319-331)

**Before:**
```html
<h4>2. Umi YAML Format (Tag Aggregation)</h4>
<div class="umi-block">Silk:
  Prompts: ["white hair archer"]
  Tags: [Demihuman]</div>
<p style="font-size:12px">Usage: <code>&lt;[Demihuman]&gt;</code> (Picks any entry with 'Demihuman' tag) or <code>&lt;[Silk]&gt;</code>.</p>
```

**After:**
```html
<h4>2. YAML Files (Tag-Based Selection)</h4>
<div class="umi-block">FireKnight:
  Prompts: ["knight in flame armor"]
  Tags: [Fire, Warrior, Heavy]

IceMage:
  Prompts: ["ice wizard"]
  Tags: [Ice, Mage, Light]</div>
<p style="font-size:12px"><strong>Tag-based:</strong> <code>&lt;[Fire]&gt;</code> (any entry with 'Fire' tag)</p>
<p style="font-size:12px"><strong>Specific entry:</strong> <code>&lt;FireKnight&gt;</code> or <code>&lt;filename:FireKnight&gt;</code></p>
<p style="font-size:12px"><strong>Logic:</strong> <code>&lt;[Fire AND Warrior]&gt;</code>, <code>&lt;[Ice OR Fire]&gt;</code>, <code>&lt;[NOT Heavy]&gt;</code></p>
```

**Changes:**
- Removed mention of "Umi YAML Format" terminology
- Shows clearer examples with multiple entries
- Demonstrates all three usage patterns: tag-based, specific entry, and logic
- More comprehensive and easier to understand

---

## Usage Examples

### Basic YAML File
```yaml
# characters.yaml
FireKnight:
  Prompts: ["knight in flame armor, red cape, fire magic"]
  Tags: [Fire, Warrior, Heavy, Male]
  Prefix: ["1girl"]
  Suffix: ["masterpiece, best quality"]

IceMage:
  Prompts: ["ice wizard, blue robes, frost staff"]
  Tags: [Ice, Mage, Light, Female]
  Prefix: ["1girl"]
  Suffix: ["masterpiece, best quality"]

ForestRanger:
  Prompts: ["forest ranger, green cloak, bow and arrow"]
  Tags: [Nature, Warrior, Light, Female]
  Prefix: ["1girl"]

DragonKnight:
  Prompts: ["dragon knight, dragon scales armor, dragon companion"]
  Tags: [Dragon, Warrior, Heavy, Male]
```

### Selection Examples

**Simple tag selection:**
```
<[Fire]>              → FireKnight
<[Female]>            → IceMage or ForestRanger (random)
<[Dragon]>            → DragonKnight
```

**AND logic:**
```
<[Fire AND Warrior]>  → FireKnight
<[Ice AND Mage]>      → IceMage
<[Female AND Light]>  → IceMage or ForestRanger
```

**OR logic:**
```
<[Fire OR Ice]>       → FireKnight or IceMage
<[Mage OR Warrior]>   → Any entry (all match)
```

**NOT logic:**
```
<[NOT Heavy]>         → IceMage or ForestRanger
<[NOT Male]>          → IceMage or ForestRanger
```

**Complex logic:**
```
<[(Fire OR Ice) AND Warrior]>    → FireKnight only
<[Female AND NOT Mage]>          → ForestRanger only
<[(Fire OR Dragon) AND Heavy]>   → FireKnight or DragonKnight
```

**Specific entry selection:**
```
<FireKnight>                     → FireKnight (by name)
<characters:IceMage>             → IceMage from characters.yaml
```

### Minimal YAML (No Tags)
You can still use YAML files without tags for simple random selection:

```yaml
# greetings.yaml
Morning:
  Prompts: ["Good morning!", "Morning sunshine!"]

Evening:
  Prompts: ["Good evening!", "Evening!"]
```

Usage:
```
<greetings:Morning>   → Random greeting from Morning entry
<greetings>           → Random greeting from any entry
```

---

## Backward Compatibility

### Existing Files Continue to Work

**Old "Umi Format" files:**
```yaml
Character1:
  Prompts: ["text"]
  Tags: [Tag1, Tag2]
```
✅ **Still works** - This is now the standard format

**Old "Alternative Format" files:**
```yaml
Category:
  Subcategory:
    - value1
    - value2
```
❌ **No longer supported** - Convert to standard format:

```yaml
Entry1:
  Prompts: ["value1"]

Entry2:
  Prompts: ["value2"]
```

### Migration Guide

If you have old hierarchical YAML files, convert them as follows:

**Before:**
```yaml
Armor:
  Heavy:
    - plate armor
    - full plate
  Light:
    - leather armor
    - cloth
```

**After:**
```yaml
PlateArmor:
  Prompts: ["plate armor", "full plate"]
  Tags: [Armor, Heavy]

LeatherArmor:
  Prompts: ["leather armor", "cloth"]
  Tags: [Armor, Light]
```

Then use: `<[Armor AND Heavy]>` or `<[Armor AND Light]>`

---

## Benefits

### 1. **Simpler Codebase**
- Removed ~40 lines of complex format detection logic
- Single code path through YAML loading
- Easier to maintain and debug

### 2. **Clearer User Experience**
- No confusion about which format to use
- One consistent YAML structure
- Better documentation with clear examples

### 3. **More Powerful Selection**
- Tag-based logic works consistently
- Complex boolean expressions supported
- Flexible querying with AND/OR/NOT/XOR/NAND/NOR

### 4. **Better Organization**
- Tags provide natural categorization
- Same entry can have multiple tags
- Easy to filter and search

### 5. **Maintained Compatibility**
- Existing Umi format files work unchanged
- Logic engine fully preserved
- All Phase 5 features still functional

---

## Testing Recommendations

### 1. **Basic Tag Selection**
Create a test YAML file:
```yaml
TestEntry1:
  Prompts: ["test prompt 1"]
  Tags: [TagA, TagB]

TestEntry2:
  Prompts: ["test prompt 2"]
  Tags: [TagB, TagC]
```

Test:
- `<[TagA]>` → Should return TestEntry1
- `<[TagB]>` → Should return TestEntry1 or TestEntry2 randomly
- `<[TagA AND TagB]>` → Should return TestEntry1
- `<[TagC]>` → Should return TestEntry2

### 2. **Logic Operators**
Test all operators:
- `<[TagA OR TagC]>` → Either entry
- `<[TagA AND TagC]>` → No matches (empty)
- `<[NOT TagC]>` → TestEntry1 only
- `<[TagA XOR TagC]>` → Either entry (exclusive)
- `<[TagB NAND TagC]>` → TestEntry1 only
- `<[TagA NOR TagC]>` → No matches

### 3. **Complex Expressions**
- `<[(TagA OR TagC) AND TagB]>` → Both entries
- `<[NOT (TagA AND TagC)]>` → Both entries (neither has both)

### 4. **File-Specific Selection**
- `<testfile:TestEntry1>` → Specific entry by name
- `<testfile:[TagB]>` → Filter testfile by tag

### 5. **Backward Compatibility**
Test your existing YAML files to ensure they still work correctly.

---

## Summary

Phase 7 successfully simplifies the YAML system by:
- ✅ Removing dual-format complexity
- ✅ Consolidating to unified tag-based approach
- ✅ Maintaining all tag logic functionality
- ✅ Improving documentation clarity
- ✅ Preserving backward compatibility with Umi format files
- ✅ Making codebase easier to maintain

The system is now cleaner, more consistent, and easier for users to understand while maintaining all the powerful tag-based selection features from Phase 5.
