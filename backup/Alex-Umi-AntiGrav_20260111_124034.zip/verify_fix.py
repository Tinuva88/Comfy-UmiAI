
import re

# Mock classes to simulate UmiAI environment

class MockVariableReplacer:
    def __init__(self):
        # The updated regex
        self.assign_regex = re.compile(r'\$([a-zA-Z0-9_]+)\s*=\s*(.*?)(?:;|(?=\n)|$)', re.MULTILINE)
        self.use_regex = re.compile(r'\$([a-zA-Z0-9_]+)((?:\.[a-zA-Z_]+)*)')
        self.variables = {}

    def store_variables(self, text):
        def _replace_assign(match):
            var_name = match.group(1)
            raw_value = match.group(2).strip()
            self.variables[var_name] = raw_value
            print(f"[DEBUG] Stored ${var_name} = '{raw_value}'")
            return "" 
        return self.assign_regex.sub(_replace_assign, text)

    def replace_variables(self, text):
        def _replace_use(match):
            var_name = match.group(1)
            val = self.variables.get(var_name, None)
            if val is not None:
                return val
            return match.group(0)
        return self.use_regex.sub(_replace_use, text)

class MockConditionalReplacer:
    def replace(self, text, variables):
        # Simple mock: handle [if $colortype=random : ...]
        # We manually parse for this test case
        if "[if" in text:
            print(f"[DEBUG] Conditional Check on: {text.strip()}")
            # Check for our specific test case
            if "random=random" in text or (variables.get('colortype') == 'random' and "$colortype" in text):
                # simplified logic simulation
                if variables.get('colortype') == 'random':
                     return "$color1=red; $color2=green"
                if "random=random" in text:
                     return "$color1=red; $color2=green"
        return text

# Simulation of the loop in nodes.py
def process(text):
    variable_replacer = MockVariableReplacer()
    conditional_replacer = MockConditionalReplacer()
    
    prompt = text
    previous_prompt = ""
    iterations = 0
    
    print(f"--- Processing: {text} ---")

    while previous_prompt != prompt and iterations < 5:
        previous_prompt = prompt
        
        # 1. Store Variables
        prompt = variable_replacer.store_variables(prompt)
        
        # 2. Replace Variables
        prompt = variable_replacer.replace_variables(prompt)
        
        # 3. Conditional Logic (Moved inside loop)
        prompt = conditional_replacer.replace(prompt, variable_replacer.variables)
        
        print(f"Iter {iterations}: {prompt.strip()}")
        iterations += 1
        
    return prompt, variable_replacer.variables

# Test Case 1: Multiple Assignments
text1 = "$a=1; $b=2"
res1, vars1 = process(text1)
print(f"Result 1 vars: {vars1}")
assert vars1.get('a') == '1'
assert vars1.get('b') == '2'

# Test Case 2: Conditional revealing variables
# User scenario:
# $colortype={random} (simulated as random)
# [if $colortype=random : $color1=red; $color2=green]
text2 = """
$colortype=random
[if $colortype=random : $color1=red; $color2=green]
Result: $color1, $color2
"""
res2, vars2 = process(text2)
print(f"Result 2: {res2.strip()}")
print(f"Result 2 vars: {vars2}")

assert vars2.get('color1') == 'red'
assert vars2.get('color2') == 'green'
if "Result: red, green" in res2:
    print("SUCCESS: Conditional logic revealed variables and they were processed!")
else:
    print("FAILURE: Variables not processed correctly.")

