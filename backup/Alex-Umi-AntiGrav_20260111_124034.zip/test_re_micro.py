import re
regex = re.compile(r'\$([a-zA-Z0-9_]+)\s*=\s*(.*?)(?:;|(?=\n)|$)', re.MULTILINE)
text = "$color1=red; $color2=green"
print(f"Testing on: '{text}'")
matches = list(regex.finditer(text))
print(f"Found {len(matches)} matches")
for m in matches:
    print(f"Match: {m.group(1)} = '{m.group(2)}'")

def sub_func(m):
    print(f"Replacing {m.group(1)}")
    return ""

new_text = regex.sub(sub_func, text)
print(f"Result text: '{new_text}'")
