import re

text = """
$color1={acid green}; $color2={ink black}; $color3={violet}
$single=value
$last=val;
"""

# Old Regex (for comparison)
old_regex = re.compile(r'^\$([a-zA-Z0-9_]+)\s*=\s*(.*?)$', re.MULTILINE)
print("--- Old Regex Matches ---")
for match in old_regex.finditer(text):
    print(f"Var: {match.group(1)}, Val: '{match.group(2)}'")

# New Regex Proposal
# We want to match $var=val until ; or newline
# We should NOT use ^ anchor if we want multiple per line
new_regex = re.compile(r'\$([a-zA-Z0-9_]+)\s*=\s*(.*?)(?:;|$)')

print("\n--- New Regex Matches ---")
# Note: This is a simplistic test. The real implementation uses sub() to replace.
# If we simply findall, we might get overlapping matches or issues.
# But let's see what it captures.
for match in new_regex.finditer(text):
    print(f"Var: {match.group(1)}, Val: '{match.group(2)}'")

# Test replacement logic
def replace_assign(match):
    print(f"Storing {match.group(1)} = {match.group(2).strip()}")
    return ""

print("\n--- New Regex Substitution ---")
new_text = new_regex.sub(replace_assign, text)
print(f"Resulting Text: '{new_text.strip()}'")
