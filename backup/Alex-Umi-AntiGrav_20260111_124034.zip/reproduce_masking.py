
import re

class MockVariableReplacer:
    def __init__(self):
        self.assign_regex = re.compile(r'\$([a-zA-Z0-9_]+)\s*=\s*([^;]+?)(?:\s*;|(?=\n)|$)', re.MULTILINE)
        self.variables = {}

    def find_matching_bracket(self, text, start):
        depth = 1
        i = start + 1
        while i < len(text) and depth > 0:
            if text[i] == '[':
                depth += 1
            elif text[i] == ']':
                depth -= 1
            i += 1
        return i - 1 if depth == 0 else -1

    def store_variables(self, text):
        # 1. Mask conditional blocks
        masked_text = text
        blocks = {}
        counter = 0
        if_start = re.compile(r'\[if\s+', re.IGNORECASE)

        # We must iterate carefully. 
        # Since we modify the string, offsets shift.
        # But we search from the beginning each time, skipping already masked tokens?
        # A simple search works if we remove the match.
        
        while True:
            match = if_start.search(masked_text)
            if not match:
                break
            
            start_pos = match.start()
            # We need to find the bracket matching the '[' at start_pos - 1?
            # 'match' is '[if '. The '[' is at match.start().
            # Wait, regex includes the bracket `\[if`.
            bracket_idx = start_pos
            
            end = self.find_matching_bracket(masked_text, bracket_idx)
            if end == -1:
                print("Unmatched bracket, stopping mask")
                break
            
            # Validate it's a valid block range
            block_content = masked_text[start_pos:end+1]
            token = f"___UMI_IF_BLOCK_{counter}___"
            blocks[token] = block_content
            
            # Replace
            masked_text = masked_text[:start_pos] + token + masked_text[end+1:]
            counter += 1

        print(f"Masked Text: {masked_text}")

        def _replace_assign(match):
            var_name = match.group(1)
            raw_value = match.group(2).strip()
            self.variables[var_name] = raw_value
            print(f"Stored global: ${var_name} = {raw_value}")
            return "" 
        
        processed_text = self.assign_regex.sub(_replace_assign, masked_text)

        # 3. Restore blocks
        for token, content in blocks.items():
            processed_text = processed_text.replace(token, content)
            
        return processed_text

# Test Input from User
text = """
$colortype={random|preset}
[if $colortype=random : $color1={__colors__}; $color2={__colors__};]
[if $colortype=preset : __colorcombo__]
"""

replacer = MockVariableReplacer()
result = replacer.store_variables(text)

print("\n--- Result ---")
print(result)
print("Variables:", replacer.variables)

# Verification
if "$color1" in replacer.variables:
    print("FAILURE: $color1 was stored (meaning it wasn't protected)")
else:
    print("SUCCESS: $color1 NOT stored (was protected)")

if "$colortype" in replacer.variables:
    print("SUCCESS: $colortype stored")
else:
    print("FAILURE: $colortype NOT stored")
