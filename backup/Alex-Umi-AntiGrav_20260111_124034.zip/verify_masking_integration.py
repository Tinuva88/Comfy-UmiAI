
import sys
import os
import types

# Add current dir to path to allow imports
sys.path.append(os.getcwd())

# MOCK ComfyUI Dependencies
folder_paths = types.ModuleType("folder_paths")
folder_paths.models_dir = "models"
folder_paths.get_full_path = lambda x, y: None
folder_paths.get_filename_list = lambda x: []
sys.modules["folder_paths"] = folder_paths

comfy = types.ModuleType("comfy")
comfy.utils = types.ModuleType("utils")
sys.modules["comfy"] = comfy

server = types.ModuleType("server")
server.PromptServer = types.ModuleType("PromptServer")
server.PromptServer.instance = types.SimpleNamespace(send_sync=lambda x, y: None)
sys.modules["server"] = server

try:
    from shared_utils import VariableReplacer
except ImportError as e:
    print(f"Could not import VariableReplacer: {e}")
    sys.exit(1)

import re

# Mock dependencies
class MockTagReplacer:
    def replace(self, text):
        return text

class MockDynamicReplacer:
    def replace(self, text):
        return text

def test_masking():
    print("--- Testing Variable Masking Integration ---")
    replacer = VariableReplacer()
    tag_replacer = MockTagReplacer()
    dynamic_replacer = MockDynamicReplacer()
    
    # 1. Test Case: Variable inside IF block (Should NOT be stored)
    text = """
    $global=stored;
    [if $cond=true : $local=hidden;]
    """
    
    # Pre-populate variables so condition logic isn't needed for this unit test of store_variables
    result = replacer.store_variables(text, tag_replacer, dynamic_replacer)
    
    print(f"Result Text:\n'{result.strip()}'")
    print(f"Stored Variables: {replacer.variables}")
    
    if "global" in replacer.variables and replacer.variables["global"] == "stored":
        print("SUCCESS: Global variable stored.")
    else:
        print("FAILURE: Global variable NOT stored.")
        
    if "local" in replacer.variables:
        print("FAILURE: Local variable inside [if] was stored (Masking failed).")
    else:
        print("SUCCESS: Local variable inside [if] was protected.")
        
    # 2. Check if text is restored correctly
    if "[if $cond=true : $local=hidden;]" in result:
         print("SUCCESS: Conditional block restored correctly.")
    else:
         print("FAILURE: Conditional block was not restored or corrupted.")

if __name__ == "__main__":
    test_masking()
