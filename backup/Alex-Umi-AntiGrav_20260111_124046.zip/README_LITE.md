# 📘 UmiAI Wildcard Processor (Lite Version)

**A Streamlined Logic Engine for ComfyUI Prompts - No External Dependencies Required**

The Lite version of UmiAI provides all the core prompt processing features without the overhead of LLM, Vision, or Danbooru integrations. Perfect for users who want powerful wildcard and logic functionality without additional dependencies or API calls.

---

## ✨ What's Included in Lite

### 🔋 Core Prompt Processing
* **🔀 Advanced Logic Engine:** Full support for `AND`, `OR`, `NOT`, `XOR`, and `( )` grouping in prompts and wildcards
* **🧠 Persistent Variables:** Define once (`$hair={Red|Blue}`), reuse everywhere with guaranteed consistency
* **🎲 Dynamic Wildcards:** Replace `__tagname__` with random selections from files
* **🔄 Random Choices:** Use `{option1|option2|option3}` for inline variations
* **💬 Comment Support:** Document complex prompts with `//` or `#` comments
* **📏 Resolution Control:** Set `@@width=1024, height=1536@@` directly in prompts

### 🎯 LoRA Management
* **🔋 Native LoRA Loading:** Type `<lora:filename:1.0>` - no external loader nodes needed
* **🛠️ Z-Image Auto-Detection:** Automatic QKV Fusion Patch for Z-Image format LoRAs
* **📊 LoRA Metadata Extraction:** Reads training tags from safetensors files
* **💾 LRU Caching:** Efficient memory management with configurable limits
* **🎛️ Tag Injection Control:** Append, Prepend, or Disable LoRA tag injection

### 📁 Data & File Support
* **📝 Multiple Formats:** TXT (line lists), YAML (structured cards), CSV (tabular data)
* **🌍 Global Presets:** Auto-load variables from `wildcards/globals.yaml`
* **🗂️ Hierarchical YAML:** Prefix/Suffix systems for complex prompt templates
* **➖ Scoped Negatives:** Use `--neg: text` to embed negative prompts
* **🔁 Recursive Processing:** Iterative refinement with cycle detection (50 passes max)
* **🎯 Seeded Determinism:** Reproducible outputs via seed control

---

## 🚫 What's Removed from Full Version

The Lite version **does not include**:
* ❌ **Vision Models** - No `[VISION: instruction]` syntax or image captioning
* ❌ **LLM Integration** - No `[LLM: tags]` syntax or prompt naturalization
* ❌ **Danbooru API** - No `char:character_name` tag fetching
* ❌ **llama-cpp-python** - No dependency installation or model downloads
* ❌ **HuggingFace Hub** - No external model fetching
* ❌ **API Calls** - Completely offline operation

### Why Choose Lite?

✅ **Smaller footprint** - No heavy dependencies
✅ **Faster installation** - No model downloads
✅ **Offline-first** - Works without internet
✅ **Lower memory usage** - No LLM models in RAM
✅ **Simpler interface** - Fewer settings to configure
✅ **Same core power** - All wildcard and logic features intact

---

## 🛠️ Installation

### Method 1: Manual Install
1. Navigate to your `ComfyUI/custom_nodes/` folder
2. Clone this repository:
   ```bash
   git clone https://github.com/Tinuva88/Comfy-UmiAI
   ```
3. **⚠️ IMPORTANT:** Rename the folder to `ComfyUI-UmiAI` if it isn't already
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. **Restart ComfyUI** completely

### Method 2: ComfyUI Manager
* Install via Git URL in ComfyUI Manager

Both the **full** and **lite** versions will be available after installation. Choose the one that fits your needs!

---

## 🔌 Wiring Guide

The Lite node works identically to the full version for basic connections:

### 1. The Main Chain
* Connect **Checkpoint Loader (Model & CLIP)** → **UmiAI Lite Node**
* Connect **UmiAI Lite Node (Model & CLIP)** → **KSampler** or **Text Encode**

### 2. Prompts & Resolution
* **Text Output** → `CLIP Text Encode` (Positive)
* **Negative Output** → `CLIP Text Encode` (Negative)
* **Width/Height** → `Empty Latent Image`

> **Setting up Resolution Control:**
> Right-click **Empty Latent Image** → **Convert width/height to input** → connect the wires

---

## ⚡ Syntax Reference (Lite Version)

| Feature | Syntax | Example |
| :--- | :--- | :--- |
| **Load LoRA** | `<lora:name:str>` | `<lora:pixel_art:0.8>` |
| **Random Choice** | `{a\|b\|c}` | `{Red\|Blue\|Green}` |
| **Logic (Prompt)** | `[if Logic : True \| False]` | `[if red AND blue : Purple]` |
| **Logic (Wildcard)**| `__[Logic]__` | `__[fire OR ice]__` |
| **Operators** | `AND`, `OR`, `NOT`, `XOR` | `[if (A OR B) AND NOT C : ...]` |
| **Variables** | `$var={opts}` | `$hair={Red\|Blue}` |
| **Equality Check** | `$var=val` | `[if $hair=Red : Fire Magic]` |
| **Wildcards** | `__filename__` | `__colors__` |
| **Weighted Range** | `1-3$$filename` | `2-4$$accessories__` |
| **YAML Tags** | `<[tagname]>` | `<[Demihuman]>` |
| **Set Size** | `@@w=X, h=Y@@` | `@@width=1024, height=1536@@` |
| **Negative Prompt** | `--neg: text` | `--neg: blurry, low quality` |
| **Comments** | `//` or `#` | `// This is a comment` |

---

## 📂 Creating Wildcards

### 1. Simple Text Lists (.txt)
Create `wildcards/colors.txt`:
```text
Red
Blue
Green
Yellow
Purple
```
**Usage:** `__colors__` picks one random color

**Weighted Ranges:** `__2-4$$colors__` picks 2-4 random colors

### 2. Advanced YAML Cards
Create `wildcards/characters.yaml`:
```yaml
Character Name - Outfit:
  Description:
    - Brief description
  Prompts:
    - 'Prompt text with <lora:example:1.0> and tags'
    - 'Alternative prompt variant'
  Tags:
    - Category
    - Trait
    - Type
  Prefix:
    - masterpiece, best quality,
  Suffix:
    - highly detailed
```

**Usage with Tags:** `<[Category]>` or `__[Category AND Trait]__`

### 3. CSV Data
Create `wildcards/data.csv`:
```csv
name,outfit,hair
Alice,red dress,blonde
Bob,suit,black
```

**Usage:** Variables auto-populate: `A portrait of $name wearing $outfit with $hair hair`

### 4. Global Variables
Create `wildcards/globals.yaml`:
```yaml
$quality: {masterpiece|high quality|best quality}
$style: {anime|realistic|painterly}
```

These load automatically in every prompt!

---

## 🚀 Example Workflows

### Example 1: Basic Variables & Logic
```text
$hair={red|blue|green}
$eyes={amber|emerald|sapphire}

A girl with $hair hair and $eyes eyes, wearing a $hair dress

[if $hair=red : fire magic, warm lighting | ice magic, cool lighting]

--neg: blurry, bad anatomy
```

### Example 2: Complex Logic
```text
$genre={fantasy **F**|scifi **S**|modern **M**}
$character={warrior|mage|rogue}

// Conditional LoRA loading
[if F: <lora:fantasy_style:0.9>]
[if S: <lora:scifi_concept:0.8>]
[if M: <lora:modern_photo:0.7>]

A $character in a $genre setting

// Nested logic for environment
[if F: medieval castle, magic particles |
[if S: space station, holographic displays |
[if M: modern city, street photography]]]

@@width=1024, height=1344@@
```

### Example 3: Wildcard Tags & Ranges
```text
// Use YAML tag filtering
__[Demihuman AND Dark Skin]__

// Weighted ranges
wearing __2-3$$accessories__, surrounded by __1-2$$elements__

// Random choices with wildcards
in the style of __ArtistNames__, {standing|sitting|floating}

--neg: worst quality, lowres
```

### Example 4: Multi-Character Setup
```text
$char1={__RandomGirls__}
$char2={__RandomBoys__}
$color1={__Colors__}
$color2={__Colors__}

A portrait of two people: $char1 wearing $color1 clothes, and $char2 wearing $color2 clothes,
{holding hands|back to back|standing together}

Background: __Background__

--neg: bad anatomy, extra limbs
```

---

## 🔧 Node Settings

### Required
* **text**: Your prompt with UmiAI syntax
* **seed**: Random seed for reproducibility

### Optional
* **model/clip**: For LoRA patching (passthrough)
* **lora_tags_behavior**: Append/Prepend/Disabled
* **lora_cache_limit**: Max cached LoRAs (default: 5)
* **width/height**: Default dimensions (default: 1024)
* **input_negative**: External negative prompt input

### Outputs
* **model/clip**: With LoRAs applied
* **text**: Processed positive prompt
* **negative_text**: Generated negative prompt
* **width/height**: Final dimensions
* **lora_info**: Loaded LoRA metadata

---

## 🎓 Tips & Best Practices

### Performance
* LoRA caching reduces load times for repeated LoRAs
* Use weighted ranges instead of multiple wildcards
* Comments are stripped early for cleaner processing

### Organization
* Use `globals.yaml` for frequently-used variables
* Group related wildcards in folders
* Comment complex logic for maintainability

### Debugging
* Test simple prompts first, add complexity gradually
* Check console for file loading errors
* Use autocomplete to verify available wildcards
* Verify all brackets are closed in logic expressions

---

## 🆘 Troubleshooting

### LoRAs Not Loading
* Ensure Model/CLIP are connected to the node
* Check LoRA filename matches (use autocomplete)
* Verify LoRAs are in ComfyUI's lora folder

### Wildcards Not Found
* Files must be in `ComfyUI-UmiAI/wildcards/` folder
* Check file extensions: `.txt`, `.yaml`, `.csv`
* Use autocomplete to see available wildcards
* Check console for file loading errors

### Logic Not Working
* Verify brackets are closed: `[if A : B | C]`
* Operators are case-sensitive: `AND`, `OR`, `NOT`, `XOR`
* Test simple conditions before nesting
* Use parentheses for complex expressions: `(A OR B) AND C`

### Variables Not Working
* Variables must start with `$`: `$myvar`
* Define before use: `$var={opts}` then `$var`
* Check `globals.yaml` is in wildcards folder

---

## 🔄 Processing Pipeline

The Lite version processes prompts in this order:

1. **Comment Stripping** - Remove `//` and `#` comments
2. **Load Globals** - Import from `wildcards/globals.yaml`
3. **Iterative Processing** (up to 50 passes):
   - Variable assignment (`$var={...}`)
   - Variable substitution (`$var`)
   - Wildcard replacement (`__tag__`)
   - Random choices (`{a|b|c}`)
4. **Conditional Logic** - Apply `[if]` statements
5. **Prefix/Suffix** - Add from YAML metadata
6. **Negative Prompts** - Collect `--neg:` entries
7. **Cleanup** - Remove duplicates, extra commas
8. **LoRA Extraction** - Parse and load LoRAs
9. **Settings Extraction** - Parse `@@width@@` and `@@height@@`
10. **Output** - Return all processed data

---

## 🏗️ Technical Details

### Architecture
* **Language**: Pure Python 3
* **Dependencies**: PyYAML, PyTorch, SafeTensors (ComfyUI standard)
* **No External APIs**: Completely offline operation
* **File Size**: ~35KB (vs ~60KB for full version)

### Removed Classes (vs Full Version)
* `VisionReplacer` - Image captioning removed
* `LLMReplacer` - Text naturalization removed
* `DanbooruReplacer` - Character tag fetching removed
* Auto-update logic - No llama-cpp-python installer

### Color Coding
* **Full Version**: Purple (`#322947`)
* **Lite Version**: Darker purple (`#47325e`)

---

## 💬 Community & Support

Join the **Umi AI** Discord for help and workflow sharing!

👉 **[Join our Discord Server](https://discord.gg/9K7j7DTfG2)**

---

## 🔀 Switching Between Versions

You can use **both** the Full and Lite versions in the same workflow! They're completely independent nodes.

### When to Use Full Version
* Need image captioning with `[VISION]`
* Want tag-to-prose conversion with `[LLM]`
* Use Danbooru character tags with `char:`
* Don't mind larger dependencies

### When to Use Lite Version
* Pure wildcard and logic processing
* Offline/air-gapped environments
* Minimal dependencies preferred
* No need for AI features
* Maximum performance focus

---

## 📄 License

Check the repository for license information.

---

**Happy Prompting! 🎨✨**
