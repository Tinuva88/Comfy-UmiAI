# UmiSaveImage Node - Connection Guide

## Overview
The **UmiSaveImage** node saves images with embedded metadata that the Image Browser can read. It preserves both your **input prompts** (with wildcards/logic) and **output prompts** (processed results).

## How to Connect

### Basic Setup (Output Prompts Only)
```
[Umi Node]
  ├─ text (output) ────────> positive_prompt (UmiSaveImage)
  ├─ negative_text (output) > negative_prompt (UmiSaveImage)
  └─ ...

[Image Generator]
  └─ IMAGE ───────────────> images (UmiSaveImage)
```

### Full Setup (Input + Output Prompts)
```
[Umi Node]
  ├─ input_text (output) ──> input_prompt (UmiSaveImage)     # Original with wildcards (NEW!)
  ├─ text (output) ────────> positive_prompt (UmiSaveImage)  # Processed result
  ├─ negative_text (output) > negative_prompt (UmiSaveImage)
  ├─ input_negative (output) > input_negative (UmiSaveImage) # Original negative (NEW!)
  └─ ...

[Image Generator]
  └─ IMAGE ───────────────> images (UmiSaveImage)
```

**IMPORTANT**: Both Full and Lite Umi nodes now have **NEW outputs**:
- `input_text` - The original input prompt (with wildcards)
- `input_negative` - The original negative prompt

## Node Inputs

### Required:
- **images**: The generated images (from KSampler, etc.)
- **filename_prefix**: Filename prefix (default: "Umi")

### Optional:
- **positive_prompt**: The processed prompt (after wildcards - connect to Umi's **text output**)
- **negative_prompt**: The processed negative (connect to Umi's **negative_text output**)
- **input_prompt**: The original input WITH wildcards (connect to Umi's **text input**)
- **input_negative**: The original negative input (connect to Umi's **input_negative input**)

## Important Notes

### Widget Name in Umi Nodes
Both the Full and Lite Umi nodes use `"text"` as the widget name for the main prompt input. This is what the Image Browser uses when copying prompts back.

### What Gets Saved
The node saves metadata as:
- `umi_prompt` - Processed positive prompt (after wildcard expansion)
- `umi_negative` - Processed negative prompt
- `umi_input_prompt` - Original input prompt (with wildcards) **← NEW**
- `umi_input_negative` - Original input negative **← NEW**
- Plus standard ComfyUI workflow data

### Image Browser Display
When you click an image in the Image Browser, you'll see:

1. **📝 Input Prompt (with wildcards)** - Your original prompt with `{choice1|choice2}`, `__wildcard__`, etc.
   - Button: "Copy Input to Umi Node" - Restores the wildcard prompt to your Umi node

2. **✨ Output Prompt (processed)** - The final prompt that was actually used
   - Button: "Copy Output" - Copies to clipboard

## Why Use This?

### Scenario 1: You want to reuse a wildcard workflow
- Connect `input_prompt` and `input_negative`
- Click "Copy Input to Umi Node" in Image Browser
- Your wildcard/logic setup is restored
- Generate again with different random results

### Scenario 2: You want to see what was actually generated
- Connect `positive_prompt` and `negative_prompt`
- View "Output Prompt (processed)" section
- See exactly what tags/prompts were used for this specific image

### Scenario 3: Best of both worlds
- Connect all 4 optional inputs
- See both input (with wildcards) and output (processed)
- Choose which one to use for future generations

## Quick Example Workflow

```
1. Add Umi Node (Full or Lite)
2. Add KSampler
3. Add UmiSaveImage node

Connections:
- Umi.input_text → UmiSaveImage.input_prompt         (NEW output!)
- Umi.text → UmiSaveImage.positive_prompt
- Umi.negative_text → UmiSaveImage.negative_prompt
- Umi.input_negative → UmiSaveImage.input_negative   (NEW output!)
- KSampler.IMAGE → UmiSaveImage.images

Generate images!
Open Image Browser (Ctrl+I) to view metadata.
```

## Troubleshooting

### "Only seeing output prompt in Image Browser"
**Problem**: You only connected `positive_prompt`, not `input_prompt`
**Solution**: Connect the Umi node's **`input_text` output** (NEW!) to UmiSaveImage's `input_prompt`
- The Umi node now has a dedicated output for the original input text with wildcards
- Look for the `input_text` connector on the right side of the Umi node

### "Copy to Umi Node doesn't work"
**Problem**: Widget name mismatch (this has been fixed)
**Solution**: Restart ComfyUI to load the updated code
- The Image Browser now correctly looks for the `"text"` widget

### "No metadata at all"
**Problem**: You're using ComfyUI's built-in SaveImage instead of UmiSaveImage
**Solution**: Use the **Umi Save Image (with metadata)** node instead

## Tips

- The `input_prompt` is what you want if you're iterating on a prompt with wildcards
- The `positive_prompt` is what you want if you want to recreate the exact same image
- You can connect both and choose later in the Image Browser!
